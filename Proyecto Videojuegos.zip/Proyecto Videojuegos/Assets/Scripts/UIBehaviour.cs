﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class UIBehaviour : MonoBehaviour {

	public void returnToScene(){
		Debug.Log ("Hey!");
		SceneManager.LoadScene ("Scene1");
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
			
	}
}
	
