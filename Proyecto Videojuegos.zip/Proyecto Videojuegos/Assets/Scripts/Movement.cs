﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.SceneManagement;

public class Movement : MonoBehaviour {

	public Text countText;
	public Text winText;

	private int counter;


	// Use this for initialization
	void Start(){
		counter = 0;
		winText.text = "";
		SetCountText ();
	}

	
	// Update is called once per frame
	void Update () {
		float h = Input.GetAxis ("Horizontal");
		float v = Input.GetAxis ("Vertical");
		//transform.Translate (h * speed * Time.deltaTime, 0, v * speed * Time.deltaTime,Space.World);
		transform.Translate (h * 10 * Time.deltaTime, 0, v * 10 * Time.deltaTime, Space.World);
	}
		

	void OnTriggerEnter(Collider other) {
		Debug.Log ("Hello");

		if (other.gameObject.CompareTag ("Coin")){
			other.gameObject.SetActive (false);
			counter= counter+1;
			SetCountText ();
		}
	}

	void SetCountText(){
		countText.text = "Count: " + counter.ToString ();
		if (counter>= 5) {
			//winText.text = "ALL COINS COLLECTED";
			SceneManager.LoadScene ("SceneWin");
		}
	}
}
