﻿using UnityEngine;
using System.Collections;

public class Rotation : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}


	void Update () {
		transform.Rotate (new Vector3 (60, 0, 0) * Time.deltaTime); 
	}
}

