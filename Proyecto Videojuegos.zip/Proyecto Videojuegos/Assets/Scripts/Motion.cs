﻿/*using UnityEngine;
using System.Collections;

public class Motion : MonoBehaviour {

	private life life;
	public int speed = 5;

	// Use this for initialization
	void Start () {
		life = GetComponent<life> ();
	}

	// Update is called once per frame
	void Update () {

		float h = Input.GetAxis ("Horizontal");
		float v = Input.GetAxis ("Vertical");
		transform.Translate (h * Time.deltaTime*speed* life.TheLife/100f, 
			0, 
			v * speed *  Time.deltaTime* life.TheLife/100f);

	}
}
*/